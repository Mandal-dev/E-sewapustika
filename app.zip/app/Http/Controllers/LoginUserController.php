<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Session;

class LoginUserController extends Controller
{


    public function showLoginPage()
    {
        return view('login.loginform'); // your Blade file
    }

    public function login(Request $request)
    {
        $request->validate([
            'mobile' => 'required|digits:10', // adjust digits as needed
        ]);

        $mobile = $request->input('mobile');

        $user = DB::table('police_users')
            ->where('mobile', $mobile)


            ->first();

        if ($user) {
            $otp = rand(100000, 999999);
            Session::put('otp', $otp);
            Session::put('otp_mobile', $mobile);
            return view('login.otpform')->with('success', 'OTP sent to your mobile.');
        }

        return back()->withErrors([
            'mobile' => 'Invalid credentials.',
        ]);
    }

    public function verifyOtp(Request $request)
    {
        // If otp[] (array) exists → combine into string
        if (is_array($request->otp)) {
            $otp = implode('', $request->otp); // e.g. ["1","2","3","4","5","6"] → "123456"
            $request->merge(['otp' => $otp]);  // overwrite as single string
        }

        // Validate OTP input
        $request->validate([
            'otp' => 'required|digits:6',
        ]);

        // Get OTP and mobile from session
        $sessionOtp = Session::get('otp');
        $mobile     = Session::get('otp_mobile');

        // If OTP session expired
        if (!$sessionOtp || !$mobile) {
            return redirect()->route('login.page')
                ->withErrors(['otp' => 'Session expired. Please login again.']);
        }

        // Match OTP
        if ($request->otp == $sessionOtp) {
            // ✅ OTP matched → get user
            $user = DB::table('police_users')
                ->select('id', 'district_id', 'designation_type', 'police_name')
                ->where('mobile', $mobile)


                ->first();

            if ($user) {
                // Clear OTP from session
                Session::forget(['otp', 'otp_mobile']);

                // Store user session
                Session::put('user', [
                    'id'               => $user->id,
                    'district_id'      => $user->district_id,
                    'designation_type' => $user->designation_type,
                    'name'             => $user->police_name,
                ]);

                return redirect()->route('dashboard')
                    ->with('success', 'Login successful! Welcome, ' . $user->police_name);
            }

            // User not found
            return redirect()->route('login.form')
                ->withErrors(['otp' => 'User not found or inactive.']);
        }

        // ❌ Wrong OTP
        return back()->withErrors(['otp' => 'Invalid OTP.']);
    }
}
