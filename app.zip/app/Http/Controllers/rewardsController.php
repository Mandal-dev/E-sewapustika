<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class rewardsController extends Controller
{
public function index()
{
    try {
        $user = Session::get('user');
        if (!$user) {
            return redirect('/');
        }

        $perPage = 10;

        // latest reward subquery
        $latestReward = DB::table('police_rewards')
            ->select(
                'id',
                'police_id',
                'reward_type',
                'rewards_documents',
                'reward_given_date',
                'reason'
            )
            ->whereRaw('id IN (SELECT MAX(id) FROM police_rewards GROUP BY police_id)');

        // base query
        $query = DB::table('police_users AS t4')
            ->join('districts AS t2', 't4.district_id', '=', 't2.id')
            ->join('states AS t1', 't2.state_id', '=', 't1.id')
            ->join('cities AS t3', 't4.city_id', '=', 't3.id')
            ->leftJoinSub($latestReward, 't5', function ($join) {
                $join->on('t4.id', '=', 't5.police_id');
            })
            ->select(
                't1.state_name',
                't1.id AS state_id',
                't2.id AS district_id',
                't2.district_name',
                't3.id AS city_id',
                't3.city_name',
                't3.status AS city_status',
                't4.id AS police_user_id',
                't4.police_name',
                't4.buckle_number',
                't4.designation_type AS role',   // 👈 role
                't5.reward_given_date',
                't5.reason',
                't5.reward_type',
                't5.rewards_documents'
            )
            ->where('t2.is_delete', 'No')
            ->where('t2.status', 'Active');

        // 👇 designation-based role filter
        switch ($user['designation_type']) {
            case 'Police':
                $query->where('t4.id', $user['id']);
                break;

            case 'Station_Head':
                $myStationId = DB::table('police_users')
                    ->where('id', $user['id'])
                    ->value('police_station_id');
                $query->where('t4.police_station_id', $myStationId);
                break;

            case 'Head_Person':
                $query->where('t4.district_id', $user['district_id']);
                break;

            case 'Admin':
                // no extra filter
                break;

            default:
                return redirect()->back()->with('error', 'Unauthorized access.');
        }

        // paginate
        $polices = $query->orderBy('t4.id', 'desc')->paginate($perPage);

        return view('rewards.index', compact('polices'));
    } catch (\Exception $e) {
        return redirect()->back()->with('error', 'Something went wrong. Please try again later.');
    }
}


public function policeRewardAdd($id)
{
    $user = Session::get('user');
    if (!$user) {
        return redirect('/');
    }

    $query = DB::table('police_users AS t4')
        ->join('districts AS t2', 't4.district_id', '=', 't2.id')
        ->join('states AS t1', 't2.state_id', '=', 't1.id')
        ->join('cities AS t3', 't4.city_id', '=', 't3.id')
        ->select(
            't4.id AS police_user_id',
            't4.police_name',
            't4.buckle_number',
            't4.designation_type AS role',   // 👈 role
            't1.id AS state_id',
            't1.state_name',
            't2.id AS district_id',
            't2.district_name',
            't3.id AS city_id',
            't3.city_name',
            't3.status AS city_status'
        )
        ->where('t4.is_delete', 'No');

    // 👇 Apply role-based filter
    switch ($user['designation_type']) {
        case 'Police':
            $query->where('t4.id', $user['id']);
            break;

        case 'Station_Head':
            $myStationId = DB::table('police_users')
                ->where('id', $user['id'])
                ->value('police_station_id');
            $query->where('t4.police_station_id', $myStationId);
            break;

        case 'Head_Person':
            $query->where('t4.district_id', $user['district_id']);
            break;

        case 'Admin':
            // no extra filter
            break;

        default:
            return redirect()->back()->with('error', 'Unauthorized access.');
    }

    $police = $query->where('t4.id', $id)
                    ->orderBy('t4.id', 'desc')
                    ->first();

    return view('rewards.add', compact('police'));
}


    public function store(Request $request)
    {
        Log::info('Reward store method hit');

        // Log input data (excluding file)
        Log::info('Request input:', $request->except(['rewards_documents']));

        // Validation
        $request->validate([
            'police_id'          => 'required|integer',
            'district_id'        => 'required|integer',
            'station_id'         => 'nullable|integer',
            'reward_given_date'  => 'required|date',
            'reward_type'        => 'required|string',
            'reason'             => 'nullable|string',
            'rewards_documents'  => 'required|file|mimes:pdf|max:5120', // 5 MB
        ]);

        try {
            // Handle the file
            $file = $request->file('rewards_documents');
            $originalName = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
            $extension = $file->getClientOriginalExtension();
            $uniqueFileName = now()->format('Ymd_His') . '_' . Str::slug($originalName) . '.' . $extension;

            // Save to root-level /uploads/rewards (NOT public)
            $destinationPath = base_path('uploads/rewards');

            if (!File::exists($destinationPath)) {
                File::makeDirectory($destinationPath, 0755, true);
            }

            $file->move($destinationPath, $uniqueFileName);
            Log::info('Reward PDF stored at: ' . $destinationPath . '/' . $uniqueFileName);

            // Insert into DB
            DB::table('police_rewards')->insert([
                'police_id'          => $request->police_id,
                'district_id'        => $request->district_id,
                'station_id'         => $request->station_id,
                'reward_given_date'  => $request->reward_given_date,
                'reward_type'        => $request->reward_type,
                'reason'             => $request->reason,
                'rewards_documents'  => $uniqueFileName,
                'created_at'         => now(),
                'updated_at'         => now(),
            ]);

            return redirect()->back()->with('success', 'बक्षीस दस्तऐवज यशस्वीरित्या अपलोड केला गेला.');
        } catch (\Exception $e) {
            Log::error('Error storing Reward Document', [
                'error' => $e->getMessage(),
            ]);

            return redirect()->back()->with('error', 'बक्षीस जतन करताना त्रुटी आली: ' . $e->getMessage());
        }
    }


    public function view($filename)
    {
        // Root-level path (not public)
        $path = base_path('uploads/rewards/' . $filename);

        if (!File::exists($path)) {
            abort(404, 'File not found.');
        }

        // Optional: check MIME type dynamically
        $mime = File::mimeType($path);

        return response()->file($path, [
            'Content-Type' => $mime ?? 'application/pdf'
        ]);
    }
}
