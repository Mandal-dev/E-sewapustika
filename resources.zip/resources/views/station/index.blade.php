@extends('Dashboard.header')

@section('data')
    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{ asset('css/table.css') }}">

    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- App Content -->
    <div class="app-content" style="margin: 0; padding: 1rem;">

        <!-- Header -->
        <div class="page-header d-flex align-items-center gap-2 mb-3"
             style="background: #fff; padding: 1rem 1.5rem; border-radius: 8px; justify-content: space-between;">
            <div class="breadcrumb d-flex align-items-center gap-2 mb-0">
                <i class="fas fa-home text-primary"></i>
                <span class="current">सर्व पोलीस ठाणे</span>
                <span>मुख्य पृष्ठ</span>
            </div>
            <span style="text-align: center;">
                <button onclick="openModal('{{ route('stations.create') }}')" class="btn btn-primary">
                    <i class="fas fa-plus"></i> पोलीस ठाणे जोडा
                </button>
            </span>
        </div>

        <!-- ✅ Flash Messages -->
        @if (session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>यशस्वी:</strong> {{ session('success') }}
            </div>
        @endif
        @if (session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>चूक:</strong> {{ session('error') }}
            </div>
        @endif

        <!-- 🔍 Search Section -->
        <div class="card p-4 mb-3">
            <div class="search-section d-flex gap-2">
                <input type="text" id="searchInput" class="form-control"
                       placeholder="नाव, ठाणे किंवा बकल क्रमांक">
                <button id="searchBtn" class="btn btn-primary">शोधा</button>
            </div>
        </div>

        <!-- ✅ Station Table -->
        <div id="stationTable" class="card p-4 mb-3">
            <div class="table-section p-3 mb-3"
                 style="background: #fff; border-radius: 1rem; box-shadow: 0 1px 3px rgba(0,0,0,0.08);">
                <h5 class="mb-2 fw-semibold">पोलीस ठाण्यांची यादी</h5>
                <p class="text-muted mb-3">एकूण नोंदी: {{ $stations->count() }}</p>

                <div class="table-responsive" style="max-height: 400px; overflow-y: auto; padding: 10px;">
                    <table class="table table-bordered align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>क्रमांक</th>
                                <th>राज्य</th>
                                <th>जिल्हा</th>
                                <th>शहर</th>
                                <th>ठाणे</th>
                                <th>स्थिती</th>
                                <th>क्रिया</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($stations as $key => $station)
                                <tr>
                                    <td>{{ $key + 1 }}</td>
                                    <td>{{ $station->state_name ?? 'N/A' }}</td>
                                    <td>{{ $station->district_name ?? 'N/A' }}</td>
                                    <td>{{ $station->city_name ?? 'N/A' }}</td>
                                    <td>{{ $station->station_name ?? 'N/A' }}</td>
                                    <td>
                                        <span class="{{ $station->status == 'Active' ? 'text-success fw-bold' : 'text-danger' }}">
                                            @if ($station->status == 'Active')
                                                <span class="status-dot"></span> {{ $station->status }}
                                            @else
                                                {{ $station->status }}
                                            @endif
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i> संपादन
                                        </button>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="7" class="text-center text-muted">नोंदी आढळल्या नाहीत</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Modal -->
        <div class="modal fade" id="sewaPustikaModal" tabindex="-1" aria-hidden="true">

            <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">

                <div class="modal-content">
                    <div class="modal-header" style ="background: #FFE0b3;">
    <h5 class="modal-title fw-bold">ठाणे जोडा</h5>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>
                    <div id="sewaPustikaModalBody" class="p-4 text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">लोड होत आहे...</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Scripts -->
    <script>
        $(document).ready(function() {
            // ✅ Auto-hide alerts
            setTimeout(() => $('.alert').fadeOut('slow'), 4000);

            // ✅ Live search
            $('#searchInput').on('keyup', function() {
                let query = $(this).val();

                $.ajax({
                    url: "{{ route('stations.search') }}",
                    method: "GET",
                    data: { search: query },
                    success: function(response) {
                        $('#stationTable').html($(response).find('#stationTable').html());
                    },
                    error: function(xhr) {
                        console.error("Search error:", xhr.responseText);
                    }
                });
            });
        });

        // ✅ Modal open function
        function openModal(url) {
            const modalElement = document.getElementById('sewaPustikaModal');
            const modal = new bootstrap.Modal(modalElement);
            modal.show();

            $('#sewaPustikaModalBody').html(`
                <div class="p-5 text-center">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">लोड होत आहे...</span>
                    </div>
                </div>
            `);

            $.ajax({
                url: url,
                type: 'GET',
                success: function(response) {
                    $('#sewaPustikaModalBody').html(response);
                },
                error: function(xhr, status, error) {
                    console.error("AJAX Error:", error, xhr.responseText);
                    $('#sewaPustikaModalBody').html(`
                        <div class="p-5 text-danger text-center">
                            डेटा लोड करण्यात अडचण आली.
                        </div>
                    `);
                }
            });
        }
    </script>
@endsection
