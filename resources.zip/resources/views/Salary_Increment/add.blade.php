<div class="modal-content">
    <!-- Fixed Header -->
    <div class="modal-header">
        <h5 class="modal-title">वेतनवाढ अपलोड करा</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>

    <form action="{{ route('salary.increment.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <!-- Scrollable Body -->
        <div class="modal-body" style="max-height: 70vh; overflow-y: auto; padding-right: 15px;">
            {{-- Show general validation errors --}}
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            {{-- राज्य आणि जिल्हा --}}
            <div class="row mb-3">
                <div class="col-md-6">
                    <label>राज्य</label>
                    <input type="text" class="form-control" value="{{ $police->state_name }}" disabled>
                    <input type="hidden" name="state_id" value="{{ $police->state_id }}">
                </div>
                <div class="col-md-6">
                    <label>जिल्हा</label>
                    <input type="text" class="form-control" value="{{ $police->district_name }}" disabled>
                    <input type="hidden" name="district_id" value="{{ $police->district_id }}">
                </div>
            </div>

            {{-- शहर आणि पोलीस नाव --}}
            <div class="row mb-3">
                <div class="col-md-6">
                    <label>शहर</label>
                    <input type="text" class="form-control" value="{{ $police->city_name }}" disabled>
                    <input type="hidden" name="station_id" value="{{ $police->city_id }}">
                </div>
                <div class="col-md-6">
                    <label>पोलीस नाव</label>
                    <input type="text" class="form-control" value="{{ $police->police_name }}" disabled>
                    <input type="hidden" name="police_id" value="{{ $police->police_user_id }}">
                </div>
            </div>

            {{-- बकल नंबर आणि वेतनवाढ दिनांक --}}
            <div class="row mb-3">
                <div class="col-md-6">
                    <label>बकल नंबर</label>
                    <input type="text" class="form-control" value="{{ $police->buckle_number }}" disabled>
                </div>
                <div class="col-md-6">
                    <label>वेतनवाढ दिनांक</label>
                    <input type="date" name="increment_date" class="form-control" required>
                    @error('increment_date')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>
            </div>

            {{-- दस्तऐवज आणि वेतनवाढ प्रकार --}}
            <div class="row mb-3">
                <div class="col-md-6">
                    <label>वेतनवाढ दस्तऐवज (PDF)</label>
                    <input type="file" name="increment_documents" class="form-control" accept=".pdf" required>
                    @error('increment_documents')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

                <div class="col-md-6">
                    <label>वेतनवाढ प्रकार</label>
                    <select name="increment_type" class="form-control" required>
                        <option value="" disabled selected>प्रकार निवडा</option>
                        <option value="दरवाढ">दरवाढ</option>
                        <option value="पदोन्नती">पदोन्नती</option>
                        <option value="इतर">इतर</option>
                    </select>
                    @error('increment_type')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>
            </div>

            {{-- नवीन वेतन, भत्ता --}}
            <div class="row mb-3">
                <div class="col-md-6">
                    <label>नवीन वेतन</label>
                    <input type="number" step="0.01" name="new_salary" class="form-control"
                        placeholder="नवीन वेतन...">
                    @error('new_salary')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

                <div class="col-md-6">
                    <label>भत्ता (Allowance)</label>
                    <input type="number" step="0.01" name="allowance" class="form-control" placeholder="भत्ता...">
                    @error('allowance')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>
            </div>

            {{-- नेट वेतन, ग्रेड पेमेण्ट --}}
            <div class="row mb-3">
                <div class="col-md-6">
                    <label>नेट वेतन</label>
                    <input type="number" step="0.01" name="net_salary" class="form-control"
                        placeholder="नेट वेतन...">
                    @error('net_salary')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

                <div class="col-md-6">
                    <!-- Choices CSS (CDN) -->
                    <link rel="stylesheet"
                        href="https://cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css" />

                    <!-- Your select inside the modal (keep id) -->
                    <select id="grade_pay_select" name="grade_pay" class="form-control">
                        <option value="">ग्रेड पेमेण्ट निवडा...</option>
                        @for ($i = 1; $i <= 31; $i++)
                            <option value="S-{{ $i }}"
                                {{ old('grade_pay', $police->grade_pay ?? '') == "S-$i" ? 'selected' : '' }}>
                                S-{{ $i }}
                            </option>
                        @endfor
                    </select>

                    <!-- limit dropdown height to ~7 items -->
                    <style>
                        .choices__list--dropdown {
                            max-height: calc(2.25rem * 7) !important;
                            overflow-y: auto !important;
                        }
                    </style>

                    <!-- Choices JS (CDN) -->
                    <script src="https://cdn.jsdelivr.net/npm/choices.js/public/assets/scripts/choices.min.js"></script>

                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            // initialize when modal opens (safer for dynamic modals)
                            const modal = document.getElementById('salaryIncrementModal'); // <-- give your modal this id
                            function initChoicesOnce() {
                                if (!document.querySelector('#grade_pay_select')) return;
                                if (window._gradePayChoices) return; // already inited
                                window._gradePayChoices = new Choices('#grade_pay_select', {
                                    searchEnabled: false,
                                    shouldSort: false,
                                    itemSelectText: '',
                                    position: 'bottom',
                                });
                            }

                            if (modal) {
                                modal.addEventListener('shown.bs.modal', initChoicesOnce);
                            } else {
                                initChoicesOnce();
                            }
                        });
                    </script>


                </div>

                {{-- वेतनवाढीची रक्कम --}}
                <div class="mb-3">
                    <label>वेतनवाढीची रक्कम (Increased Amount)</label>
                    <input type="number" step="0.01" name="increased_amount" class="form-control"
                        placeholder="वेतनवाढीची रक्कम...">
                    @error('increased_amount')
                        <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>
            </div> <!-- modal-body -->

            <!-- Footer -->
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">सबमिट करा</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">रद्द करा</button>
            </div>
    </form>
</div>
