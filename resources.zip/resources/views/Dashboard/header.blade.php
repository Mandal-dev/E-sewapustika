<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maharashtra Police Admin Dashboard</title>

    <!-- Google Icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- FontAwesome for extra icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="{{ asset('css/new_dashboard.css') }}">
</head>

<body>

    <!-- Sidebar -->
    <aside id="sidebar" class="sidebar">
        <div class="sidebar-header">
            <h1>Maharashtra<br>Police</h1>
            <p>Admin System</p>
        </div>

        <nav class="nav">
            <!-- Dashboard -->
            <a href="#" class="active">
                <span class="material-icons">grid_view</span> Dashboard
            </a>

            @php
                $designation = Session::get('user.designation_type');
            @endphp

            <!-- Manage Masters (Only Admin / Head_Person) -->
            @if (in_array($designation, ['Admin', 'Head_Person']))
                <div class="nav-group">
                    <div class="nav-group-header">
                        <i class="fas fa-users"></i>
                        <span>Manage Masters</span>
                        <i class="fas fa-chevron-down arrow"></i>
                    </div>
                    <div class="nav-submenu">
                        @if (in_array($designation, ['Admin']))
                            <a href="{{ route('districts.index') }}" class="nav-item submenu-item">
                                <i class="fas fa-map-marker-alt"></i> जिल्हा व्यवस्थापन
                            </a>
                            <a href="{{ route('city.index') }}" class="nav-item submenu-item">
                                <i class="fas fa-city"></i> शहर व्यवस्थापन
                            </a>
                        @endif
                        <a href="{{ route('station.index') }}" class="nav-item submenu-item">
                            <i class="fas fa-building"></i> पोलीस ठाणे व्यवस्थापन
                        </a>
                        <a href="{{ route('police.list.index') }}" class="nav-item submenu-item">
                            <i class="fas fa-user-shield"></i> पोलीस वापरकर्ता व्यवस्थापन
                        </a>
                    </div>
                </div>
            @endif

            <!-- Police Information -->
            <div class="nav-group">
                <div class="nav-group-header">
                    <i class="fas fa-clipboard-list"></i>
                    <span>Police Information</span>
                    <i class="fas fa-chevron-down arrow"></i>
                </div>
                <div class="nav-submenu">
                    <a href="{{ route('sewa_pustika.index') }}" class="nav-item submenu-item"><i
                            class="fas fa-book"></i> सेवा पुस्तिका</a>
                    <a href="{{ route('salary_increment.index') }}" class="nav-item submenu-item"><i
                            class="fas fa-chart-line"></i> वेतनवाढ</a>
                    <a href="{{ route('punishments.index') }}" class="nav-item submenu-item"><i
                            class="fas fa-exclamation-triangle"></i> शिक्षा</a>
                    <a href="{{ route('rewards.index') }}" class="nav-item submenu-item"><i class="fas fa-trophy"></i>
                        बक्षीस</a>

                    <a href="{{ route('sewa_pustika.index') }}" class="nav-item submenu-item"><i
                            class="fas fa-comment"></i> पुरस्काराची स्थिती</a>
                </div>
            </div>
        </nav>
    </aside>

    <!-- Backdrop -->
    <div id="backdrop"></div>

    <!-- Main Content -->
    <div id="mainContent">
        <header>
            <button id="menuBtn"><span class="material-icons">menu</span> Dashboard</button>
        </header>

        <main style="padding:1rem;">


            @yield('data')
        </main>
    </div>

    <!-- JS -->
    <script>
        const menuBtn = document.getElementById('menuBtn');
        const sidebar = document.getElementById('sidebar');
        const backdrop = document.getElementById('backdrop');
        const mainContent = document.getElementById('mainContent');

        // Toggle Sidebar
        function toggleSidebar() {
            if (window.innerWidth >= 768) {
                sidebar.classList.toggle('hidden-sidebar');
                mainContent.style.marginLeft = sidebar.classList.contains('hidden-sidebar') ? '0' : '16rem';
            } else {
                sidebar.classList.toggle('open');
                backdrop.style.display = sidebar.classList.contains('open') ? 'block' : 'none';
            }
        }

        // Init Sidebar
        function initSidebar() {
            if (window.innerWidth >= 768) {
                sidebar.classList.remove('hidden-sidebar');
                sidebar.classList.add('open');
                mainContent.style.marginLeft = '16rem';
                backdrop.style.display = 'none';
            } else {
                sidebar.classList.remove('open', 'hidden-sidebar');
                mainContent.style.marginLeft = '0';
                backdrop.style.display = 'none';
            }
        }

        menuBtn.addEventListener('click', toggleSidebar);
        backdrop.addEventListener('click', toggleSidebar);
        window.addEventListener('resize', initSidebar);
        document.addEventListener('DOMContentLoaded', initSidebar);

        // Submenu toggle
        document.querySelectorAll('.nav-group-header').forEach(header => {
            header.addEventListener('click', () => {
                const submenu = header.nextElementSibling;
                submenu.classList.toggle('open');
                header.classList.toggle('active');

                // Close other menus
                document.querySelectorAll('.nav-group-header').forEach(other => {
                    if (other !== header) {
                        other.classList.remove('active');
                        other.nextElementSibling.classList.remove('open');
                    }
                });
            });
        });

        // Highlight active link
        document.querySelectorAll('.nav a, .submenu a, .nav-submenu a').forEach(link => {
            link.addEventListener('click', () => {
                document.querySelectorAll('.nav a, .submenu a, .nav-submenu a').forEach(l => l.classList
                    .remove('active'));
                link.classList.add('active');
            });
        });
    </script>
</body>

</html>
